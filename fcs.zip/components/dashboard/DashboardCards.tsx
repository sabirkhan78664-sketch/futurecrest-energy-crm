import StatsCard from "./StatsCard";

const stats = [
  { title: "Total Leads", value: 0, color: "text-blue-600" },
  { title: "New", value: 0, color: "text-cyan-600" },
  { title: "Callback", value: 0, color: "text-yellow-600" },
  { title: "Pending", value: 0, color: "text-orange-600" },
  { title: "Sold", value: 0, color: "text-green-600" },
  { title: "Rejected", value: 0, color: "text-red-600" },
];

export default function DashboardCards() {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
      {stats.map((item) => (
        <StatsCard
          key={item.title}
          title={item.title}
          value={item.value}
          color={item.color}
        />
      ))}
    </div>
  );
}