interface StatsCardProps {
  title: string;
  value: number;
  color?: string;
}

export default function StatsCard({
  title,
  value,
  color = "text-blue-600",
}: StatsCardProps) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm transition hover:shadow-md">
      <p className="text-sm font-medium text-slate-500">{title}</p>

      <h2 className={`mt-3 text-4xl font-bold ${color}`}>
        {value}
      </h2>
    </div>
  );
}