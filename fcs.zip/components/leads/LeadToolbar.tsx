"use client";

interface Props {
  search: string;
  setSearch: (value: string) => void;
  status: string;
  setStatus: (value: string) => void;
  fuel: string;
  setFuel: (value: string) => void;
  agent: string;
  setAgent: (value: string) => void;
  campaign: string;
  setCampaign: (value: string) => void;
  uniqueAgents: string[];
  uniqueCampaigns: string[];
}

export default function LeadToolbar({
  search,
  setSearch,
  status,
  setStatus,
  fuel,
  setFuel,
  agent,
  setAgent,
  campaign,
  setCampaign,
  uniqueAgents,
  uniqueCampaigns,
}: Props) {
  return (
    <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
      
      <input
        type="text"
        placeholder="Search ID, Customer, Mobile, NMI, Campaign, Agent..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full md:max-w-md rounded-lg border border-gray-300 px-4 py-3 outline-none focus:border-blue-500"
      />

      <div className="flex flex-wrap items-center gap-3">
        
        {/* Agent Filter */}
        <select
          value={agent}
          onChange={(e) => setAgent(e.target.value)}
          className="rounded-lg border border-gray-300 px-4 py-3"
        >
          <option value="">All Agents</option>
          {uniqueAgents.map((a) => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>

        {/* Campaign Filter */}
        <select
          value={campaign}
          onChange={(e) => setCampaign(e.target.value)}
          className="rounded-lg border border-gray-300 px-4 py-3"
        >
          <option value="">All Campaigns</option>
          {uniqueCampaigns.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        {/* Status Filter */}
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded-lg border border-gray-300 px-4 py-3"
        >
          <option value="">All Status</option>
          <option value="New">New</option>
          <option value="Attempt 1">Attempt 1</option>
          <option value="Attempt 2">Attempt 2</option>
          <option value="Callback">Callback</option>
          <option value="Interested">Interested</option>
          <option value="Documents Pending">Documents Pending</option>
          <option value="Verification">Verification</option>
          <option value="Sale">Sale</option>
          <option value="No Answer">No Answer</option>
          <option value="Wrong Number">Wrong Number</option>
          <option value="DNCR">DNCR</option>
          <option value="Rejected">Rejected</option>
          <option value="Lost">Lost</option>
          <option value="Duplicate">Duplicate</option>
        </select>

        {/* Fuel Filter */}
        <select
          value={fuel}
          onChange={(e) => setFuel(e.target.value)}
          className="rounded-lg border border-gray-300 px-4 py-3"
        >
          <option value="">All Fuel</option>
          <option value="Electricity">Electricity</option>
          <option value="Gas">Gas</option>
          <option value="Dual Fuel">Dual Fuel</option>
        </select>

      </div>
    </div>
  );
}