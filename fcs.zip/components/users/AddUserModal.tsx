"use client";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function AddUserModal({
  open,
  onClose,
}: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">

      <div className="w-full max-w-2xl rounded-xl bg-white p-8 shadow-xl">

        <div className="mb-6 flex items-center justify-between">

          <h2 className="text-2xl font-bold">
            Add New User
          </h2>

          <button
            onClick={onClose}
            className="text-2xl"
          >
            ×
          </button>

        </div>

        <div className="grid grid-cols-2 gap-5">

          <input
            className="rounded border p-3"
            placeholder="Full Name"
          />

          <input
            className="rounded border p-3"
            placeholder="Email"
          />

          <input
            className="rounded border p-3"
            placeholder="Phone"
          />

          <select className="rounded border p-3">

            <option>Agent</option>

            <option>Closer</option>

            <option>Supervisor</option>

            <option>Super Admin</option>

          </select>

          <input
            type="password"
            className="rounded border p-3"
            placeholder="Password"
          />

          <select className="rounded border p-3">

            <option>Active</option>

            <option>Inactive</option>

          </select>

        </div>

        <div className="mt-8 flex justify-end gap-3">

          <button
            onClick={onClose}
            className="rounded border px-6 py-3"
          >
            Cancel
          </button>

          <button
            className="rounded bg-blue-600 px-6 py-3 text-white"
          >
            Create User
          </button>

        </div>

      </div>

    </div>
  );
}