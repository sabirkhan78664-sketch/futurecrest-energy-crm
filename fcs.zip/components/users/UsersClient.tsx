"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import UserTable from "./UserTable";
import AddUserModal from "./AddUserModal";
import EditUserModal from "./EditUserModal";
import DeleteUserDialog from "./DeleteUserDialog";
import { deleteUser } from "@/lib/users";

interface User {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  role: string;
  status: string;
  created_at: string;
}

interface Props {
  users: User[];
}

export default function UsersClient({ users }: Props) {
  const router = useRouter();

  const [open, setOpen] = useState(false);

  const [editOpen, setEditOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  async function handleDelete() {
    if (!userToDelete) return;

    try {
      setDeleteLoading(true);

      await deleteUser(userToDelete.id);

      alert("User deleted successfully.");

      setDeleteOpen(false);
      setUserToDelete(null);

      router.refresh();
    } catch (err) {
      console.error(err);
      alert("Failed to delete user.");
    } finally {
      setDeleteLoading(false);
    }
  }

  return (
    <>
      <div className="mb-6 flex justify-end">
        <button
          onClick={() => setOpen(true)}
          className="rounded-lg bg-blue-600 px-5 py-3 text-white hover:bg-blue-700"
        >
          + Add User
        </button>
      </div>

      <AddUserModal
        open={open}
        onClose={() => {
          setOpen(false);
          router.refresh();
        }}
      />

      <EditUserModal
        open={editOpen}
        user={selectedUser}
        onClose={() => {
          setEditOpen(false);
          setSelectedUser(null);
        }}
        onSaved={() => {
          setEditOpen(false);
          setSelectedUser(null);
          router.refresh();
        }}
      />

      <DeleteUserDialog
        open={deleteOpen}
        loading={deleteLoading}
        userName={userToDelete?.full_name ?? ""}
        onClose={() => {
          setDeleteOpen(false);
          setUserToDelete(null);
        }}
        onConfirm={handleDelete}
      />

      <UserTable
        users={users}
        onEdit={(user) => {
          setSelectedUser(user);
          setEditOpen(true);
        }}
        onDelete={(user) => {
          setUserToDelete(user);
          setDeleteOpen(true);
        }}
      />
    </>
  );
}