"use client";

import { UserPen, Trash2 } from "lucide-react";

interface User {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  role: string;
  status: string;
  created_at: string;
}

interface Props {
  users: User[];
  onEdit: (user: User) => void;
  onDelete: (user: User) => void;
}

export default function UserTable({
  users,
  onEdit,
  onDelete,
}: Props) {
  return (
    <div className="overflow-hidden rounded-xl border bg-white shadow">
      <table className="min-w-full">
        <thead className="bg-slate-100">
          <tr>
            <th className="px-5 py-4 text-left">Name</th>
            <th className="px-5 py-4 text-left">Email</th>
            <th className="px-5 py-4 text-left">Phone</th>
            <th className="px-5 py-4 text-left">Role</th>
            <th className="px-5 py-4 text-left">Status</th>
            <th className="px-5 py-4 text-left">Created</th>
            <th className="px-5 py-4 text-center">Actions</th>
          </tr>
        </thead>

        <tbody>
          {users.length === 0 ? (
            <tr>
              <td
                colSpan={7}
                className="py-10 text-center text-slate-500"
              >
                No users found.
              </td>
            </tr>
          ) : (
            users.map((user) => (
              <tr
                key={user.id}
                className="border-t hover:bg-slate-50"
              >
                <td className="px-5 py-4">
                  {user.full_name}
                </td>

                <td className="px-5 py-4">
                  {user.email}
                </td>

                <td className="px-5 py-4">
                  {user.phone || "-"}
                </td>

                <td className="px-5 py-4">
                  {user.role}
                </td>

                <td className="px-5 py-4">
                  <span
                    className={`rounded-full px-3 py-1 text-sm ${
                      user.status === "Active"
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                    }`}
                  >
                    {user.status}
                  </span>
                </td>

                <td className="px-5 py-4">
                  {new Date(user.created_at).toLocaleDateString("en-AU")}
                </td>

                <td className="px-5 py-4 text-center">
                  <button
                    onClick={() => onEdit(user)}
                    className="mr-2 rounded bg-blue-600 p-2 text-white hover:bg-blue-700"
                  >
                    <UserPen size={16} />
                  </button>

                  <button
                    onClick={() => onDelete(user)}
                    className="rounded bg-red-600 p-2 text-white hover:bg-red-700"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}