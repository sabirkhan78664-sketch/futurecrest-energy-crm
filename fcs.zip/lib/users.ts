import { supabase } from "./supabase";

export async function getUsers() {
  const { data, error } = await supabase
    .from("users")
    .select("*")
    .order("id", { ascending: false });

  if (error) {
    console.error(error);
    return [];
  }

  return data ?? [];
}

export async function deleteUser(id: number) {
  const res = await fetch(`/api/users/${id}`, {
    method: "DELETE",
  });

  const result = await res.json();

  if (!result.success) {
    throw new Error(result.message);
  }

  return true;
}