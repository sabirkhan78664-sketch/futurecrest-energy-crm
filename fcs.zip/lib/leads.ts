import { supabase } from "./supabase";

export async function getLeads() {
  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .order("id", { ascending: false });

  if (error) {
    console.error("Supabase Error:", error);
    return [];
  }

  return data ?? [];
}

export async function getLead(id: number) {
  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    console.error(error);
    return null;
  }

  return data;
}

export async function deleteLead(id: number) {
  const { error } = await supabase
    .from("leads")
    .delete()
    .eq("id", id);

  if (error) {
    console.error(error);
    throw error;
  }

  return true;
}

export async function updateLead(id: number, values: any) {
  const { error } = await supabase
    .from("leads")
    .update(values)
    .eq("id", id);

  if (error) {
    console.error(error);
    throw error;
  }

  return true;
}