"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import MainLayout from "@/components/layout/MainLayout";

export default function AgentsPage() {
  const [agents, setAgents] = useState<any[]>([]);

  useEffect(() => {
    async function fetchAgents() {
      const { data } = await supabase.from("agents").select("*");
      if (data) setAgents(data);
    }
    fetchAgents();
  }, []);

  return (
    <MainLayout>
      <h1 className="text-2xl font-bold mb-6">Team Management</h1>
      <div className="grid gap-4">
        {agents.map((agent) => (
          <div key={agent.id} className="bg-white p-4 rounded-lg border shadow-sm flex justify-between">
            <span>{agent.name}</span>
            <span className="text-sm text-gray-500">{agent.role}</span>
          </div>
        ))}
      </div>
    </MainLayout>
  );
}