import MainLayout from "@/components/layout/MainLayout";
import DashboardCards from "@/components/dashboard/DashboardCards";
import AuthProvider from "@/components/AuthProvider";

export default function DashboardPage() {
  return (
    <AuthProvider>
      <MainLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-800">
              Dashboard
            </h1>

            <p className="text-slate-500">
              Welcome to FutureCrest Energy CRM
            </p>
          </div>

          <DashboardCards />

          {/* Charts Coming Soon */}

          {/* Recent Leads Coming Soon */}
        </div>
      </MainLayout>
    </AuthProvider>
  );
}