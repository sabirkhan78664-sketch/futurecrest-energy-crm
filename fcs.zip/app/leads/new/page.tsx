"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import MainLayout from "@/components/layout/MainLayout";

export default function NewLeadPage() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // Function to trigger WhatsApp
  const openWhatsApp = (phone: string, name: string) => {
    const message = `Hello ${name}, thanks for reaching out to FutureCrest Energy! How can we help you today?`;
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const name = formData.get("name") as string;
    const phone = formData.get("phone") as string;
    
    // Save to database
    const { error } = await supabase.from("leads").insert({
      name: name,
      phone: phone,
      status: "New",
      campaign: formData.get("campaign"),
    });

    if (error) {
      alert(error.message);
      setLoading(false);
    } else {
      // After saving, immediately open WhatsApp for this lead
      openWhatsApp(phone, name);
      router.push("/dashboard");
    }
  }

  return (
    <MainLayout>
      <h1 className="text-2xl font-bold mb-6">Add New Lead</h1>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border shadow-sm max-w-lg">
        <input name="name" placeholder="Customer Name" required className="w-full p-3 mb-4 border rounded" />
        <input name="phone" placeholder="Phone Number (e.g., 919876543210)" required className="w-full p-3 mb-4 border rounded" />
        <input name="campaign" placeholder="Campaign Name" className="w-full p-3 mb-6 border rounded" />
        
        <button 
          disabled={loading} 
          className="w-full bg-blue-600 text-white py-3 rounded font-bold hover:bg-blue-700 transition"
        >
          {loading ? "Saving..." : "Save Lead & Message"}
        </button>
      </form>
      
      <p className="mt-4 text-sm text-gray-500">
        *Tip: Ensure the phone number includes the country code without '+' (e.g., 91 for India).
      </p>
    </MainLayout>
  );
}