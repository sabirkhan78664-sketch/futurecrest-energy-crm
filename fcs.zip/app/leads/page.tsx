import MainLayout from "@/components/layout/MainLayout";
import LeadsClient from "@/components/leads/LeadsClient";
import { getLeads } from "@/lib/leads";
import Link from "next/link";

export default async function LeadsPage() {
  const leads = await getLeads();

  const totalLeads = leads.length;

  const sales = leads.filter(
    (lead: any) => lead.status === "Sale"
  ).length;

  const pending = leads.filter(
    (lead: any) => lead.status === "Pending"
  ).length;

  const callbacks = leads.filter(
    (lead: any) => lead.status === "Callback"
  ).length;

  return (
    <MainLayout>
      <div className="space-y-6">

        <div className="flex items-center justify-between">

          <div>
            <h1 className="text-3xl font-bold">
              Lead Management
            </h1>

            <p className="text-slate-500">
              Manage FutureCrest Energy Leads
            </p>
          </div>

          <Link
            href="/leads/new"
            className="rounded-lg bg-blue-600 px-5 py-3 text-white hover:bg-blue-700"
          >
            + New Lead
          </Link>

        </div>

        <div className="grid grid-cols-4 gap-5">

          <div className="rounded-xl border bg-white p-6 shadow">
            <h3 className="text-slate-500">
              Total Leads
            </h3>

            <p className="mt-2 text-3xl font-bold">
              {totalLeads}
            </p>
          </div>

          <div className="rounded-xl border bg-white p-6 shadow">
            <h3 className="text-slate-500">
              Sales
            </h3>

            <p className="mt-2 text-3xl font-bold text-green-600">
              {sales}
            </p>
          </div>

          <div className="rounded-xl border bg-white p-6 shadow">
            <h3 className="text-slate-500">
              Pending
            </h3>

            <p className="mt-2 text-3xl font-bold text-yellow-600">
              {pending}
            </p>
          </div>

          <div className="rounded-xl border bg-white p-6 shadow">
            <h3 className="text-slate-500">
              Callbacks
            </h3>

            <p className="mt-2 text-3xl font-bold text-blue-600">
              {callbacks}
            </p>
          </div>

        </div>

        <LeadsClient leads={leads} />

      </div>
    </MainLayout>
  );
}