"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import { Briefcase, Save, User, Zap } from "lucide-react";

interface LeadFormProps {
  initialData?: any;
  isEdit?: boolean;
}

export default function LeadForm({
  initialData,
  isEdit = false,
}: LeadFormProps) {
  const router = useRouter();

  const [customerName, setCustomerName] = useState(
    initialData?.customer_name || ""
  );
  const [mobile, setMobile] = useState(
    initialData?.mobile || ""
  );
  const [nmi, setNmi] = useState(
    initialData?.nmi || ""
  );
  const [currentRetailer, setCurrentRetailer] = useState(
    initialData?.current_retailer || ""
  );
  const [offeredRetailer, setOfferedRetailer] = useState(
    initialData?.offered_retailer || ""
  );
  const [fuelType, setFuelType] = useState(
    initialData?.fuel_type || ""
  );
  const [campaign, setCampaign] = useState(
    initialData?.campaign || ""
  );
  const [status, setStatus] = useState(
    initialData?.status || "New"
  );
  const [assignedAgent, setAssignedAgent] = useState(
    initialData?.assigned_agent || ""
  );
  const [callbackDate, setCallbackDate] = useState(
    initialData?.callback_date || ""
  );
  const [callbackTime, setCallbackTime] = useState(
    initialData?.callback_time || ""
  );

  const [agents, setAgents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadAgents() {
      const { data } = await supabase
        .from("users")
        .select("id, full_name")
        .eq("role", "Agent")
        .eq("status", "Active")
        .order("full_name");

      setAgents(data || []);
    }
    loadAgents();
  }, []);

  async function saveLead() {
    if (!customerName || !mobile) {
      alert("Please fill in at least the Customer Name and Mobile.");
      return;
    }

    if (status === "Callback" && (!callbackDate || !callbackTime)) {
      alert("Please select a Callback Date and Time.");
      return;
    }

    setLoading(true);
    let error;

    const finalCallbackDate = status === "Callback" ? callbackDate : null;
    const finalCallbackTime = status === "Callback" ? callbackTime : null;

    if (isEdit) {
      const result = await supabase
        .from("leads")
        .update({
          customer_name: customerName,
          mobile,
          nmi,
          current_retailer: currentRetailer,
          offered_retailer: offeredRetailer,
          fuel_type: fuelType,
          campaign,
          status,
          assigned_agent: assignedAgent,
          callback_date: finalCallbackDate,
          callback_time: finalCallbackTime,
        })
        .eq("id", initialData.id);

      error = result.error;
    } else {
      const leadId = `FCE-${Date.now()}`;
      const result = await supabase
        .from("leads")
        .insert([
          {
            lead_id: leadId,
            customer_name: customerName,
            mobile,
            nmi,
            current_retailer: currentRetailer,
            offered_retailer: offeredRetailer,
            fuel_type: fuelType,
            campaign,
            status,
            assigned_agent: assignedAgent,
            callback_date: finalCallbackDate,
            callback_time: finalCallbackTime,
          },
        ]);

      error = result.error;
    }

    setLoading(false);

    if (error) {
      alert(error.message);
      return;
    }

    alert(isEdit ? "Lead Updated Successfully" : "Lead Saved Successfully");
    router.push("/leads");
    router.refresh();
  }

  return (
    <div className="w-full">
      {/* Top Header & Save Button */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">
          {isEdit ? "Edit Lead" : "New Lead"}
        </h1>

        <button
          onClick={saveLead}
          disabled={loading}
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-6 py-2.5 font-semibold text-white shadow-sm transition-colors hover:bg-blue-700 disabled:opacity-50"
        >
          <Save size={18} />
          {loading ? "Saving..." : "Save Changes"}
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        
        {/* Left Column - Main Details */}
        <div className="space-y-6 lg:col-span-2">
          
          {/* Customer Information Card */}
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-2 border-b pb-3 text-lg font-semibold text-gray-800">
              <User size={20} className="text-blue-600" />
              Customer Information
            </div>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Customer Name</label>
                <input
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. John Doe"
                />
              </div>
              
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Mobile Number</label>
                <input
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="e.g. 0412345678"
                />
              </div>
            </div>
          </div>

          {/* Energy Information Card */}
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-2 border-b pb-3 text-lg font-semibold text-gray-800">
              <Zap size={20} className="text-yellow-500" />
              Energy Information
            </div>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">NMI</label>
                <input
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={nmi}
                  onChange={(e) => setNmi(e.target.value)}
                  placeholder="National Meter Identifier"
                />
              </div>
              
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Fuel Type</label>
                <select
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={fuelType}
                  onChange={(e) => setFuelType(e.target.value)}
                >
                  <option value="">Select Fuel</option>
                  <option value="Electricity">Electricity</option>
                  <option value="Gas">Gas</option>
                  <option value="Dual Fuel">Dual Fuel</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Current Retailer</label>
                <input
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={currentRetailer}
                  onChange={(e) => setCurrentRetailer(e.target.value)}
                  placeholder="e.g. AGL, Origin"
                />
              </div>
              
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Offered Retailer</label>
                <input
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={offeredRetailer}
                  onChange={(e) => setOfferedRetailer(e.target.value)}
                  placeholder="e.g. Alinta"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Status & Sidebar */}
        <div className="space-y-6">
          
          {/* Assignment & Status Card */}
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-2 border-b pb-3 text-lg font-semibold text-gray-800">
              <Briefcase size={20} className="text-purple-600" />
              Assignment & Status
            </div>
            
            <div className="space-y-5">
              
              {isEdit && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Lead ID</p>
                  <p className="mt-1 font-mono font-semibold text-gray-900">{initialData?.lead_id}</p>
                </div>
              )}

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Current Status</label>
                <select
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option value="New">New</option>
                  <option value="Attempt 1">Attempt 1</option>
                  <option value="Attempt 2">Attempt 2</option>
                  <option value="Callback">Callback</option>
                  <option value="Interested">Interested</option>
                  <option value="Documents Pending">Documents Pending</option>
                  <option value="Verification">Verification</option>
                  <option value="Sale">Sale</option>
                  <option value="No Answer">No Answer</option>
                  <option value="Wrong Number">Wrong Number</option>
                  <option value="DNCR">DNCR</option>
                  <option value="Rejected">Rejected</option>
                  <option value="Lost">Lost</option>
                  <option value="Duplicate">Duplicate</option>
                </select>
              </div>

              {/* Dynamic Callback Fields */}
              {status === "Callback" && (
                <div className="rounded-lg border border-blue-100 bg-blue-50 p-4 space-y-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-blue-800">Callback Date</label>
                    <input
                      type="date"
                      className="w-full rounded-md border border-blue-200 p-2 text-gray-900 outline-none focus:border-blue-500"
                      value={callbackDate}
                      onChange={(e) => setCallbackDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-blue-800">Callback Time</label>
                    <input
                      type="time"
                      className="w-full rounded-md border border-blue-200 p-2 text-gray-900 outline-none focus:border-blue-500"
                      value={callbackTime}
                      onChange={(e) => setCallbackTime(e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Assigned Agent</label>
                <select
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={assignedAgent}
                  onChange={(e) => setAssignedAgent(e.target.value)}
                >
                  <option value="">Select Agent</option>
                  {agents.map((agent) => (
                    <option key={agent.id} value={agent.full_name}>
                      {agent.full_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600">Campaign</label>
                <input
                  className="w-full rounded-lg border border-gray-300 p-2.5 text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={campaign}
                  onChange={(e) => setCampaign(e.target.value)}
                  placeholder="e.g. Winter Promo"
                />
              </div>

              {isEdit && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Created Date</p>
                  <p className="mt-1 font-semibold text-gray-900">
                    {initialData?.created_at
                      ? new Intl.DateTimeFormat("en-AU", {
                          day: "2-digit",
                          month: "long",
                          year: "numeric",
                          timeZone: "UTC",
                        }).format(new Date(initialData.created_at))
                      : "-"}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}