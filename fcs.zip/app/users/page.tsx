import MainLayout from "@/components/layout/MainLayout";
import { supabase } from "@/lib/supabase";
import Link from "next/link";
import { Plus, Shield, User, UserCheck } from "lucide-react";

export default async function UsersPage() {
  // Fetch all users from your database
  const { data: users } = await supabase
    .from("users")
    .select("*")
    .order("full_name");

  return (
    <MainLayout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-slate-500">Manage your team members and their roles</p>
        </div>
        <Link
          href="/users/new"
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-3 text-white hover:bg-blue-700"
        >
          <Plus size={18} />
          Add New User
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {users?.map((user) => (
          <div key={user.id} className="rounded-xl border bg-white p-6 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-600">
                <User size={24} />
              </div>
              <div>
                <h3 className="font-bold text-lg">{user.full_name}</h3>
                <p className="text-sm text-slate-500">{user.email}</p>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between border-t pt-4">
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                user.role === 'Admin' ? 'bg-purple-100 text-purple-700' :
                user.role === 'Agent' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
              }`}>
                {user.role}
              </span>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                user.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'
              }`}>
                {user.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </MainLayout>
  );
}