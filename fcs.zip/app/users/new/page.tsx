"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import MainLayout from "@/components/layout/MainLayout";

export default function NewUserPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Agent");
  const [status, setStatus] = useState("Active");
  const [loading, setLoading] = useState(false);

  async function addUser(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const { error } = await supabase
      .from("users")
      .insert([{ full_name: fullName, email, role, status }]);

    setLoading(false);

    if (error) {
      alert("Error adding user: " + error.message);
    } else {
      alert("User added successfully!");
      router.push("/users");
      router.refresh();
    }
  }

  return (
    <MainLayout>
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-6 text-3xl font-bold">Add New Team Member</h1>
        
        <form onSubmit={addUser} className="rounded-xl border bg-white p-8 shadow-sm space-y-6">
          <div>
            <label className="mb-2 block font-medium">Full Name</label>
            <input
              required
              className="w-full rounded-lg border p-3 outline-none focus:border-blue-500"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>

          <div>
            <label className="mb-2 block font-medium">Email Address</label>
            <input
              required
              type="email"
              className="w-full rounded-lg border p-3 outline-none focus:border-blue-500"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="mb-2 block font-medium">Role</label>
              <select
                className="w-full rounded-lg border p-3 outline-none focus:border-blue-500"
                value={role}
                onChange={(e) => setRole(e.target.value)}
              >
                <option value="Agent">Agent</option>
                <option value="Closer">Closer</option>
                <option value="Admin">Admin</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block font-medium">Status</label>
              <select
                className="w-full rounded-lg border p-3 outline-none focus:border-blue-500"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <button
            disabled={loading}
            className="w-full rounded-lg bg-blue-600 py-3 font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? "Adding..." : "Add User"}
          </button>
        </form>
      </div>
    </MainLayout>
  );
}