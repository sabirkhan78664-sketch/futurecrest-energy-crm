"use client";

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { LayoutDashboard, Users, PhoneCall, BarChart3, UserCog, Briefcase, Settings, Import } from 'lucide-react';

export default function Home() {
  const [activePage, setActivePage] = useState('Dashboard');
  const [recentLeads, setRecentLeads] = useState<any[]>([]);
  // Add this line below:
  const [currentUser, setCurrentUser] = useState('Alice Johnson'); 
  // ... rest of your state

  useEffect(() => {
    async function fetchLeads() {
      const { data } = await supabase.from('leads').select('*');
      if (data) setRecentLeads(data);
    }
    fetchLeads();
  }, []);

  const stats = [
    { id: 'total', label: 'Total Leads', val: recentLeads.length },
    { id: 'new', label: 'New', val: recentLeads.filter(l => l.Status === 'New').length },
    { id: 'callback', label: 'Callback', val: recentLeads.filter(l => l.Status === 'Callback').length },
    { id: 'sold', label: 'Sold', val: recentLeads.filter(l => l.Status === 'Sold').length },
    { id: 'pending', label: 'Pending', val: recentLeads.filter(l => l.Status === 'Pending').length },
    { id: 'rejected', label: 'Rejected', val: recentLeads.filter(l => l.Status === 'Rejected').length },
  ];

  const navItems = [
    { name: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { name: 'Leads', icon: <Users size={20} /> },
    { name: 'Follow-ups', icon: <PhoneCall size={20} /> },
    { name: 'Sales', icon: <BarChart3 size={20} /> },
    { name: 'Reports', icon: <BarChart3 size={20} /> },
    { name: 'Agents', icon: <UserCog size={20} /> },
    { name: 'Closers', icon: <Briefcase size={20} /> },
    { name: 'Import Leads', icon: <Import size={20} /> },
    { name: 'Settings', icon: <Settings size={20} /> },
  ];

  const statusOptions = ['All', 'New', 'Callback', 'Sold', 'Pending', 'Rejected'];

  return (
    <div className="flex h-screen bg-slate-100 font-sans">
      <nav className="w-64 bg-slate-900 text-white p-4">
        <h1 className="text-xl font-bold mb-8 px-4">FutureCrest <span className="text-blue-400">ENERGY CRM</span></h1>
        <div className="space-y-1">
          {navItems.map((item) => (
            <button key={item.name} onClick={() => setActivePage(item.name)} 
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg ${activePage === item.name ? 'bg-blue-600' : 'hover:bg-slate-800'}`}>
              {item.icon} {item.name}
            </button>
          ))}
        </div>
      </nav>

      <main className="flex-1 p-8 overflow-y-auto">
        <h2 className="text-2xl font-bold mb-6">{activePage}</h2>

        {activePage === 'Dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-6 gap-4">
              {stats.map((s) => (
                <div key={s.id} className="bg-white p-4 rounded-xl shadow-sm border text-center">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">{s.label}</p>
                  <p className="text-xl font-bold">{s.val}</p>
                </div>
              ))}
            </div>

            <div className="bg-white p-5 rounded-xl border">
              <h3 className="font-bold mb-4">Recent Leads</h3>
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b text-slate-500">
                    <th className="pb-3">Name</th>
                    <th className="pb-3">Mobile</th>
                    <th className="pb-3">NMI</th>
                    <th className="pb-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentLeads.map((lead) => (
                    <tr key={lead.id || Math.random()} className="border-b">
                      <td className="py-3">{lead.Name}</td>
                      <td className="py-3">{lead.Mobile}</td>
                      <td className="py-3">{lead.NMI}</td>
                      <td className="py-3">{lead.Status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}