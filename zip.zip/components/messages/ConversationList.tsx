"use client";

import Link from "next/link";

interface ConversationListProps {
  conversations: any[];
  currentUserId: string;
}

export default function ConversationList({
  conversations,
  currentUserId,
}: ConversationListProps) {
  return (
    <div className="h-full border-r bg-white">

      <div className="border-b p-4">
        <h2 className="text-xl font-semibold">
          Conversations
        </h2>
      </div>

      <div className="divide-y">

        {conversations.length === 0 && (
          <div className="p-6 text-gray-500">
            No conversations found.
          </div>
        )}

        {conversations.map((conversation) => {

          const otherUser =
            conversation.user_one === currentUserId
              ? conversation.user2
              : conversation.user1;

          return (
            <Link
              key={conversation.id}
              href={`/messages/${conversation.id}`}
              className="block p-4 hover:bg-gray-100"
            >
              <div className="font-semibold">
                {otherUser?.full_name}
              </div>

              <div className="text-sm text-gray-500">
                {otherUser?.employee_id}
              </div>

              <div className="text-xs text-blue-600">
                {otherUser?.role}
              </div>
            </Link>
          );
        })}

      </div>

    </div>
  );
}