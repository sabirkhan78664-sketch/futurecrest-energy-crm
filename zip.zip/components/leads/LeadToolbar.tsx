"use client";

import Link from "next/link";
import { RefreshCw, Plus } from "lucide-react";

interface Props {
  search: string;
  setSearch: (value: string) => void;

  status: string;
  setStatus: (value: string) => void;

  fuel: string;
  setFuel: (value: string) => void;

  agent: string;
  setAgent: (value: string) => void;

  campaign: string;
  setCampaign: (value: string) => void;

  uniqueAgents: string[];
  uniqueCampaigns: string[];
}

export default function LeadToolbar({
  search,
  setSearch,
  status,
  setStatus,
  fuel,
  setFuel,
  agent,
  setAgent,
  campaign,
  setCampaign,
  uniqueAgents,
  uniqueCampaigns,
}: Props) {
  function resetFilters() {
    setSearch("");
    setStatus("");
    setFuel("");
    setAgent("");
    setCampaign("");
  }

  return (
    <div className="mb-6 rounded-xl border bg-white p-5 shadow">

      <div className="grid grid-cols-1 gap-4 md:grid-cols-6">

        <input
          className="rounded-lg border p-3 md:col-span-2"
          placeholder="Search Lead ID, Customer, Mobile..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          className="rounded-lg border p-3"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="">All Status</option>
          <option>New</option>
          <option>Attempt 1</option>
          <option>Attempt 2</option>
          <option>Callback</option>
          <option>Interested</option>
          <option>Documents Pending</option>
          <option>Verification</option>
          <option>Sale</option>
          <option>No Answer</option>
          <option>Wrong Number</option>
          <option>DNCR</option>
          <option>Rejected</option>
          <option>Lost</option>
          <option>Duplicate</option>
        </select>

        <select
          className="rounded-lg border p-3"
          value={fuel}
          onChange={(e) => setFuel(e.target.value)}
        >
          <option value="">All Fuel</option>
          <option>Electricity</option>
          <option>Gas</option>
          <option>Dual Fuel</option>
        </select>

        <select
          className="rounded-lg border p-3"
          value={campaign}
          onChange={(e) => setCampaign(e.target.value)}
        >
          <option value="">All Campaigns</option>

          {uniqueCampaigns.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>

        <select
          className="rounded-lg border p-3"
          value={agent}
          onChange={(e) => setAgent(e.target.value)}
        >
          <option value="">All Agents</option>

          {uniqueAgents.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>

      </div>

      <div className="mt-5 flex items-center justify-between">

        <button
          onClick={resetFilters}
          className="rounded-lg bg-gray-200 px-5 py-2 hover:bg-gray-300"
        >
          Reset Filters
        </button>

        <div className="flex gap-3">

          <button
            onClick={() => window.location.reload()}
            className="flex items-center gap-2 rounded-lg border px-5 py-2 hover:bg-slate-100"
          >
            <RefreshCw size={16} />
            Refresh
          </button>

          <Link
            href="/leads/new"
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-white hover:bg-blue-700"
          >
            <Plus size={16} />
            New Lead
          </Link>

        </div>

      </div>

    </div>
  );
}