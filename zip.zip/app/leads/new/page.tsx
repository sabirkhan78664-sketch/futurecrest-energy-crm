import MainLayout from "@/components/layout/MainLayout";
import AgentForm from "@/components/agents/AgentForm";
import Link from "next/link";

export default function NewAgentPage() {
  return (
    <MainLayout>
      <div className="max-w-5xl space-y-6">

        <div className="flex items-center justify-between">

          <div>
            <h1 className="text-3xl font-bold">
              Add New Agent
            </h1>

            <p className="text-slate-500">
              Create a new FutureCrest CRM user
            </p>
          </div>

          <Link
            href="/agents"
            className="rounded-lg border px-5 py-2"
          >
            Back
          </Link>

        </div>

        <AgentForm />

      </div>
    </MainLayout>
  );
}