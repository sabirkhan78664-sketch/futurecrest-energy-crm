import ConversationList from "@/components/messages/ConversationList";

export default function MessagesPage() {
  return (
    <div className="grid h-[calc(100vh-100px)] grid-cols-12">

      <div className="col-span-3">
        <ConversationList
          conversations={[]}
          currentUserId=""
        />
      </div>

      <div className="col-span-9 flex items-center justify-center bg-gray-50">

        <div className="text-center">

          <h2 className="text-2xl font-bold">
            Messages
          </h2>

          <p className="mt-2 text-gray-500">
            Select a conversation to start chatting.
          </p>

        </div>

      </div>

    </div>
  );
}