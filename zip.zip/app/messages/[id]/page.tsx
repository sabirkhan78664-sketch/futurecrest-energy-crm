import ChatWindow from "@/components/messages/ChatWindow";
import {
  getMessages,
  markAsRead,
} from "@/lib/messages";

interface Props {
  params: {
    id: string;
  };
}

export default async function ChatPage({
  params,
}: Props) {
  const conversationId = Number(params.id);

  // Replace with your logged-in user's ID
  const currentUserId = "";

  await markAsRead(
    conversationId,
    currentUserId
  );

  const messages = await getMessages(
    conversationId
  );

  return (
    <ChatWindow
      messages={messages}
      currentUserId={currentUserId}
      conversationId={conversationId}
    />
  );
}